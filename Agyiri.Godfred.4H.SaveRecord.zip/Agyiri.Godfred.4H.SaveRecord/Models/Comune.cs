namespace godfr.Desktop.Agyiri.Godfred.4H.SaveRecord.Models
{

      public class Comune
    {


       public class Comuni : List<Comune>
       {

       }

   public void Save()
       {
           string[] colonne = NomeFile.Split(",")[0] + ".bin";
           Save(fileName);
       }

      public void Load(string fileName)
      {
          FileStream fin = new FileStream(fileName);
          BinaryReader reader  = new BinaryReader(fin);

          Comune c = new Comune();

          c.ID = reade.ReadInt32();
          c.CodiceCastale = reader.ReadString();
          c.NomeComune = reader.ReaderString();
          Add (c);
      }



        public void Save(string fileName)
        {
            FileStream fout = new FileStream("ComuniBin.bin", FileMode.Create);

            foreach(Comune comune in this)
            {
            writer.Write(comune.ID);
            writer.Unit();
            }
        }
      
     
 

    }
}